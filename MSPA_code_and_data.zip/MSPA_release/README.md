# MSPA: Multi-view Semantic Prototype and Cross-View Alignment

Reference implementation of the paper *"MSPA: Multi-view Semantic Prototype and
Cross-View Alignment for Bundle Recommendation"*.

Youshu and NetEase are bundled, so the code runs out of the box on those two
datasets. The iFashion split is **not** included, to keep the upload below the
size limit; see *Data* below for how to add it in one step.

## What is new compared with the backbone

The multi-view propagation backbone follows **MultiCBR** (Ma et al., *MultiCBR:
Multi-View Contrastive Learning for Bundle Recommendation*, ACM TOIS 2024).
Two modules are contributed by the paper and implemented in
`models/MultiCBR.py`:

| Module | Function |
|---|---|
| Prototype enhancement (PE) | `compute_proto_assignment`, `enhance_bi`, `cal_proto_loss` (augmentation-consistency KL), prototype orthogonality term |
| Cross-view alignment (CVA) | `cal_cross_view_alignment_loss` — couples the U-B, U-I and B-I representations of the same entity before fusion |

## Environment

* Python 3.8 or newer (tested with 3.10)
* PyTorch 1.9 or newer (CPU or CUDA)
* numpy, scipy, pyyaml, tqdm, tensorboard

```bash
pip install -r requirements.txt
```

## Data

`datasets/Youshu/` and `datasets/NetEase/` contain the two bundled splits, in
the format of the CrossCBR release:

```
datasets/<name>/<name>_data_size.txt   # #users  #bundles  #items
datasets/<name>/user_bundle_{train,tune,test}.txt
datasets/<name>/user_item.txt
datasets/<name>/bundle_item.txt
datasets/<name>/*_id_map.json          # iFashion only
```

To run on iFashion as well, download the dataset from the CrossCBR release
(<https://github.com/mysbupt/CrossCBR>) and copy it to `datasets/iFashion/`
using the same file names; the `iFashion` block of `config.yaml` is already
provided. On Linux/macOS:

```bash
unzip iFashion_data.zip -d datasets/      # produces datasets/iFashion/
```

The datasets originate from <https://github.com/mysbupt/CrossCBR>; please cite
CrossCBR (and the original data providers) when you use them.

## Run

```bash
python train.py -g 0 -d Youshu        # Youshu, GPU 0   (bundled)
python train.py -g 0 -d NetEase       # NetEase         (bundled)
python train.py -g 0 -d iFashion      # iFashion        (add datasets/iFashion first)
python train.py -g 0 -d Youshu -i dbg # extra tag appended to the run name
```

`-g` selects the GPU (`CUDA_VISIBLE_DEVICES`); the code falls back to CPU when no
CUDA device is available. `-c` points to an alternative configuration file and
`-s` sets the random seed (default 42).

All hyper-parameters are read from `config.yaml`, which has one block per
dataset. The keys added for this paper are

| Key | Meaning |
|---|---|
| `num_protos` | size *K* of the learnable prototype bank |
| `proto_alpha` | residual fusion coefficient α of the prototype injection |
| `proto_temp` | temperature τ of the soft assignment |
| `beta` | weight of the augmentation-consistency KL loss |
| `proto_pred_lambda` | weight of the prototype-prediction auxiliary loss |
| `cross_view_lambda` | weight λ_cva of the cross-view alignment loss |
| `fusion_weights` | fixed fusion weights of the three views and of the GNN layers |
| `num_workers` | DataLoader workers (0 is the portable default) |

## Expected results

Recall@20/40 and NDCG@20/40 reported in the paper (Table 3); the iFashion row
requires the extra dataset download described above:

| Dataset | R@20 | N@20 | R@40 | N@40 |
|---|---|---|---|---|
| iFashion | 0.1507 | 0.1229 | 0.2056 | 0.1428 |
| NetEase | 0.0941 | 0.0497 | 0.1359 | 0.0638 |
| Youshu | 0.2914 | 0.1725 | 0.4013 | 0.2007 |

The best validation checkpoint is kept and the matching test scores are written
to `log/<dataset>/<model>/<setting>`; TensorBoard event files go to
`runs/<dataset>/<model>/<setting>` and the checkpoint plus its configuration to
`checkpoints/<dataset>/<model>/{model,conf}/<setting>`.

## Repository layout

```
train.py               training / evaluation loop, metric computation, logging
utility.py             dataset loading and the BPR training datasets
models/MultiCBR.py     model: MultiCBR backbone + PE and CVA modules
config.yaml            per-dataset hyper-parameters
datasets/              Youshu, NetEase, iFashion (included)
requirements.txt       dependencies
```

## Notes on reproducibility

* The prototype bank is created per run, so a fixed seed (`-s`) is recommended
  when comparing runs.
* `beta = 0` disables the second augmented B-I branch used by the
  augmentation-consistency loss; `cross_view_lambda = 0` disables CVA and the
  prototype injection can be disabled with `proto_alpha = 0`. The ablation rows
  of the paper correspond to these switches.
* Please check the hyper-parameters in `config.yaml` against the values reported
  in the paper before comparing numbers.

## Citation

```bibtex
@article{sun2026mspa,
  title   = {MSPA: Multi-view Semantic Prototype and Cross-View Alignment for Bundle Recommendation},
  author  = {Sun, Zhigang and Niu, Guangjin and Wang, Li'e},
  journal = {International Journal of Machine Learning and Cybernetics},
  year    = {2026}
}
```

## Contact

Corresponding author: Li'e Wang. Questions about the code can also be addressed
to the second author.
