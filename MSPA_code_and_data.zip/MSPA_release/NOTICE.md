# Provenance and scope of this package

## What this package contains

* `train.py`, `utility.py`, `models/MultiCBR.py`, `config.yaml` — the code used
  for the experiments in the paper.
* `datasets/` — the Youshu and NetEase splits used in the paper. The iFashion
  split is not redistributed here in order to keep the archive small; it is
  available in the public CrossCBR release.

## What it does not contain

* Trained checkpoints, TensorBoard event files and run logs: these are
  experiment artifacts and are not needed to reproduce the results (they are
  regenerated under `checkpoints/`, `runs/` and `log/` when you run the code).
* Data preprocessing scripts, baseline implementations and the plotting scripts
  of the figures: these are not required to reproduce the reported results and
  are available from the authors on request.

## Third-party material

* The multi-view propagation backbone follows the public MultiCBR
  implementation (Ma et al., ACM TOIS 2024). Please cite MultiCBR when you use
  this code.
* The datasets are redistributed in the format of the public CrossCBR release
  (<https://github.com/mysbupt/CrossCBR>). Please cite CrossCBR and the original
  data providers.

## Licence

No licence file is bundled yet: before making the package public, add the
licence you want to release your own code under (for example MIT or Apache-2.0)
and keep this notice so that the attribution to MultiCBR and CrossCBR stays
visible.
