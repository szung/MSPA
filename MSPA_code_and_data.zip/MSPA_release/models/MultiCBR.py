#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MSPA: Multi-view Semantic Prototype and Cross-View Alignment.

The multi-view propagation backbone follows MultiCBR (Ma et al., "MultiCBR:
Multi-View Contrastive Learning for Bundle Recommendation", ACM TOIS 2024).
The two modules contributed by this paper are:

* Prototype enhancement (PE): a learnable global prototype bank on the B-I
  view, with soft assignment (``compute_proto_assignment``), prototype
  aggregation and residual fusion (``enhance_bi``), plus the
  augmentation-consistency KL loss (``cal_proto_loss``) and the orthogonality
  term used in ``forward``.
* Cross-view alignment (CVA): ``cal_cross_view_alignment_loss``, which couples
  the U-B, U-I and B-I representations of the same entity before fusion.

Both modules are switched on through ``config.yaml``; see README.md.
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import scipy.sparse as sp 


def cal_bpr_loss(pred):
    # pred: [bs, 1+neg_num]
    if pred.shape[1] > 2:
        negs = pred[:, 1:]
        pos = pred[:, 0].unsqueeze(1).expand_as(negs)
    else:
        negs = pred[:, 1].unsqueeze(1)
        pos = pred[:, 0].unsqueeze(1)

    loss = -F.logsigmoid(pos - negs)  # numerically stable [bs]
    loss = torch.mean(loss)

    return loss


def laplace_transform(graph):
    rowsum_sqrt = sp.diags(1/(np.sqrt(graph.sum(axis=1).A.ravel()) + 1e-8))
    colsum_sqrt = sp.diags(1/(np.sqrt(graph.sum(axis=0).A.ravel()) + 1e-8))
    graph = rowsum_sqrt @ graph @ colsum_sqrt

    return graph


def to_tensor(graph):
    graph = graph.tocoo()
    values = graph.data
    indices = np.vstack((graph.row, graph.col))
    idx_t = torch.LongTensor(indices)
    val_t = torch.FloatTensor(values)
    if hasattr(torch.sparse, "FloatTensor"):
        graph = torch.sparse.FloatTensor(idx_t, val_t, torch.Size(graph.shape))
    else:  # torch >= 2.x may drop the legacy constructor
        graph = torch.sparse_coo_tensor(idx_t, val_t, torch.Size(graph.shape))

    return graph


def np_edge_dropout(values, dropout_ratio):
    mask = np.random.choice([0, 1], size=(len(values),), p=[dropout_ratio, 1-dropout_ratio])
    values = mask * values
    return values


class MultiCBR(nn.Module):
    def __init__(self, conf, raw_graph):
        super().__init__()
        self.conf = conf
        device = self.conf["device"]
        self.device = device

        self.embedding_size = conf["embedding_size"]
        self.embed_L2_norm = conf["l2_reg"]
        self.num_users = conf["num_users"]
        self.num_bundles = conf["num_bundles"]
        self.num_items = conf["num_items"]
        self.num_layers = self.conf["num_layers"]
        self.c_temp = self.conf["c_temp"]

        self.fusion_weights = conf['fusion_weights']

        self.init_emb()
        self.init_fusion_weights()

        assert isinstance(raw_graph, list)
        self.ub_graph, self.ui_graph, self.bi_graph = raw_graph

        # generate the graph without any dropouts for testing
        self.UB_propagation_graph_ori = self.get_propagation_graph(self.ub_graph)

        self.UI_propagation_graph_ori = self.get_propagation_graph(self.ui_graph)
        self.UI_aggregation_graph_ori = self.get_aggregation_graph(self.ui_graph)

        self.BI_propagation_graph_ori = self.get_propagation_graph(self.bi_graph)
        self.BI_aggregation_graph_ori = self.get_aggregation_graph(self.bi_graph)

        # generate the graph with the configured dropouts for training, if aug_type is OP or MD, the following graphs with be identical with the aboves
        self.UB_propagation_graph = self.get_propagation_graph(self.ub_graph, self.conf["UB_ratio"])

        self.UI_propagation_graph = self.get_propagation_graph(self.ui_graph, self.conf["UI_ratio"])
        self.UI_aggregation_graph = self.get_aggregation_graph(self.ui_graph, self.conf["UI_ratio"])

        self.BI_propagation_graph = self.get_propagation_graph(self.bi_graph, self.conf["BI_ratio"])
        self.BI_aggregation_graph = self.get_aggregation_graph(self.bi_graph, self.conf["BI_ratio"])

        if self.conf['aug_type'] == 'MD':
            self.init_md_dropouts()
        elif self.conf['aug_type'] == "Noise":
            self.init_noise_eps()

        # Prototype network parameters
        self.num_protos = conf.get("num_protos", 8)
        self.proto_alpha = conf.get("proto_alpha", 0.1)
        self.proto_temp = conf.get("proto_temp", 0.1)
        self.beta = conf.get("beta", 0.0)

        self.prototypes = nn.Parameter(torch.FloatTensor(self.num_protos, self.embedding_size))
        nn.init.xavier_normal_(self.prototypes)

        self.cached_a_b1 = None
        self.cached_a_b2 = None

    def init_md_dropouts(self):
        self.UB_dropout = nn.Dropout(self.conf["UB_ratio"], True)
        self.UI_dropout = nn.Dropout(self.conf["UI_ratio"], True)
        self.BI_dropout = nn.Dropout(self.conf["BI_ratio"], True)
        self.mess_dropout_dict = {
            "UB": self.UB_dropout,
            "UI": self.UI_dropout,
            "BI": self.BI_dropout
        }


    def init_noise_eps(self):
        self.UB_eps = self.conf["UB_ratio"]
        self.UI_eps = self.conf["UI_ratio"]
        self.BI_eps = self.conf["BI_ratio"]
        self.eps_dict = {
            "UB": self.UB_eps,
            "UI": self.UI_eps,
            "BI": self.BI_eps
        }


    def init_emb(self):
        self.users_feature = nn.Parameter(torch.FloatTensor(self.num_users, self.embedding_size))
        nn.init.xavier_normal_(self.users_feature)
        self.bundles_feature = nn.Parameter(torch.FloatTensor(self.num_bundles, self.embedding_size))
        nn.init.xavier_normal_(self.bundles_feature)
        self.items_feature = nn.Parameter(torch.FloatTensor(self.num_items, self.embedding_size))
        nn.init.xavier_normal_(self.items_feature)


    def init_fusion_weights(self):
        assert (len(self.fusion_weights['modal_weight']) == 3), \
            "The number of modal fusion weights does not correspond to the number of graphs"

        assert (len(self.fusion_weights['UB_layer']) == self.num_layers + 1) and\
               (len(self.fusion_weights['UI_layer']) == self.num_layers + 1) and \
               (len(self.fusion_weights['BI_layer']) == self.num_layers + 1),\
            "The number of layer fusion weights does not correspond to number of layers"

        modal_coefs = torch.FloatTensor(self.fusion_weights['modal_weight'])
        UB_layer_coefs = torch.FloatTensor(self.fusion_weights['UB_layer'])
        UI_layer_coefs = torch.FloatTensor(self.fusion_weights['UI_layer'])
        BI_layer_coefs = torch.FloatTensor(self.fusion_weights['BI_layer'])

        self.modal_coefs = modal_coefs.unsqueeze(-1).unsqueeze(-1).to(self.device)

        self.UB_layer_coefs = UB_layer_coefs.unsqueeze(0).unsqueeze(-1).to(self.device)
        self.UI_layer_coefs = UI_layer_coefs.unsqueeze(0).unsqueeze(-1).to(self.device)
        self.BI_layer_coefs = BI_layer_coefs.unsqueeze(0).unsqueeze(-1).to(self.device)


    def get_propagation_graph(self, bipartite_graph, modification_ratio=0):
        device = self.device
        propagation_graph = sp.bmat([[sp.csr_matrix((bipartite_graph.shape[0], bipartite_graph.shape[0])), bipartite_graph], [bipartite_graph.T, sp.csr_matrix((bipartite_graph.shape[1], bipartite_graph.shape[1]))]])

        if modification_ratio != 0:
            if self.conf["aug_type"] == "ED":
                graph = propagation_graph.tocoo()
                values = np_edge_dropout(graph.data, modification_ratio)
                propagation_graph = sp.coo_matrix((values, (graph.row, graph.col)), shape=graph.shape).tocsr()

        return to_tensor(laplace_transform(propagation_graph)).to(device)


    def get_aggregation_graph(self, bipartite_graph, modification_ratio=0):
        device = self.device

        if modification_ratio != 0:
            if self.conf["aug_type"] == "ED":
                graph = bipartite_graph.tocoo()
                values = np_edge_dropout(graph.data, modification_ratio)
                bipartite_graph = sp.coo_matrix((values, (graph.row, graph.col)), shape=graph.shape).tocsr()

        bundle_size = bipartite_graph.sum(axis=1) + 1e-8
        bipartite_graph = sp.diags(1/bundle_size.A.ravel()) @ bipartite_graph
        return to_tensor(bipartite_graph).to(device)


    def propagate(self, graph, A_feature, B_feature, graph_type, layer_coef, test):
        features = torch.cat((A_feature, B_feature), 0)
        if not test:
            features = F.dropout(features, p=self.conf.get("dropout", 0.0), training=self.training)
        all_features = [features]

        for i in range(self.num_layers):
            features = torch.spmm(graph, features)
            if self.conf["aug_type"] == "MD" and not test:
                mess_dropout = self.mess_dropout_dict[graph_type]
                features = mess_dropout(features)
            elif self.conf["aug_type"] == "Noise" and not test:
                random_noise = torch.rand_like(features).to(self.device)
                eps = self.eps_dict[graph_type]
                features += torch.sign(features) * F.normalize(random_noise, dim=-1) * eps

            all_features.append(F.normalize(features, p=2, dim=1))

        all_features = torch.stack(all_features, 1) * layer_coef
        all_features = torch.sum(all_features, dim=1)
        A_feature, B_feature = torch.split(all_features, (A_feature.shape[0], B_feature.shape[0]), 0)

        return A_feature, B_feature


    def aggregate(self, agg_graph, node_feature, graph_type, test):
        aggregated_feature = torch.matmul(agg_graph, node_feature)

        # simple embedding dropout on bundle embeddings
        if self.conf["aug_type"] == "MD" and not test:
            mess_dropout = self.mess_dropout_dict[graph_type]
            aggregated_feature = mess_dropout(aggregated_feature)
        elif self.conf["aug_type"] == "Noise" and not test:
            random_noise = torch.rand_like(aggregated_feature).to(self.device)
            eps = self.eps_dict[graph_type]
            aggregated_feature += torch.sign(aggregated_feature) * F.normalize(random_noise, dim=-1) * eps

        return aggregated_feature


    def fuse_users_bundles_feature(self, users_feature, bundles_feature):
        users_feature = torch.stack(users_feature, dim=0)
        bundles_feature = torch.stack(bundles_feature, dim=0)

        # Modal aggregation
        users_rep = torch.sum(users_feature * self.modal_coefs, dim=0)
        bundles_rep = torch.sum(bundles_feature * self.modal_coefs, dim=0)

        return users_rep, bundles_rep


    def get_multi_modal_representations(self, test=False):
        #  =============================  UB graph propagation  =============================
        if test:
            UB_users_feature, UB_bundles_feature = self.propagate(self.UB_propagation_graph_ori, self.users_feature, self.bundles_feature, "UB", self.UB_layer_coefs, test)
        else:
            UB_users_feature, UB_bundles_feature = self.propagate(self.UB_propagation_graph, self.users_feature, self.bundles_feature, "UB", self.UB_layer_coefs, test)

        #  =============================  UI graph propagation  =============================
        if test:
            UI_users_feature, UI_items_feature = self.propagate(self.UI_propagation_graph_ori, self.users_feature, self.items_feature, "UI", self.UI_layer_coefs, test)
            UI_bundles_feature = self.aggregate(self.BI_aggregation_graph_ori, UI_items_feature, "BI", test)
        else:
            UI_users_feature, UI_items_feature = self.propagate(self.UI_propagation_graph, self.users_feature, self.items_feature, "UI", self.UI_layer_coefs, test)
            UI_bundles_feature = self.aggregate(self.BI_aggregation_graph, UI_items_feature, "BI", test)

        #  =============================  BI graph propagation  =============================
        if test:
            BI_bundles_feature, BI_items_feature = self.propagate(self.BI_propagation_graph_ori, self.bundles_feature, self.items_feature, "BI", self.BI_layer_coefs, test)
            BI_users_feature = self.aggregate(self.UI_aggregation_graph_ori, BI_items_feature, "UI", test)
            BI_bundles_feature, a_b = self.enhance_bi(BI_bundles_feature)
            self.cached_a_b = a_b
        else:
            BI_bundles_feature1, BI_items_feature1 = self.propagate(self.BI_propagation_graph, self.bundles_feature, self.items_feature, "BI", self.BI_layer_coefs, test)
            BI_users_feature = self.aggregate(self.UI_aggregation_graph, BI_items_feature1, "UI", test)
            if self.beta > 0:
                BI_bundles_feature2, _ = self.propagate(self.BI_propagation_graph, self.bundles_feature, self.items_feature, "BI", self.BI_layer_coefs, test)
                BI_bundles_feature1, a_b1 = self.enhance_bi(BI_bundles_feature1)
                BI_bundles_feature2, a_b2 = self.enhance_bi(BI_bundles_feature2)
                self.cached_proto_loss = self.cal_proto_loss(a_b1, a_b2)
                self.cached_a_b1 = a_b1
                self.cached_a_b2 = a_b2
                self.cached_a_b = a_b1  # cache the assignments for the auxiliary losses
                BI_bundles_feature = BI_bundles_feature1
            else:
                BI_bundles_feature, a_b = self.enhance_bi(BI_bundles_feature1)
                self.cached_a_b = a_b

        users_feature = [UB_users_feature, UI_users_feature, BI_users_feature]
        bundles_feature = [UB_bundles_feature, UI_bundles_feature, BI_bundles_feature]

        # cache the three view representations for the cross-view alignment loss
        self.cached_view_users = (UB_users_feature, UI_users_feature, BI_users_feature)
        self.cached_view_bundles = (UB_bundles_feature, UI_bundles_feature, BI_bundles_feature)

        users_rep, bundles_rep = self.fuse_users_bundles_feature(users_feature, bundles_feature)

        return users_rep, bundles_rep


    def cal_c_loss(self, pos, aug):
        # pos: [batch_size, :, emb_size]
        # aug: [batch_size, :, emb_size]
        pos = pos[:, 0, :]
        aug = aug[:, 0, :]

        pos = F.normalize(pos, p=2, dim=1)
        aug = F.normalize(aug, p=2, dim=1)
        pos_score = torch.sum(pos * aug, dim=1) # [batch_size]
        ttl_score = torch.matmul(pos, aug.permute(1, 0)) # [batch_size, batch_size]

        pos_score = pos_score / self.c_temp
        ttl_score = ttl_score / self.c_temp
        # numerically stable InfoNCE
        c_loss = -torch.mean(pos_score - torch.logsumexp(ttl_score, dim=1))

        return c_loss

    def cal_cross_view_alignment_loss(self):
        """Cross-view alignment loss over the three views of the same entity."""
        if not hasattr(self, 'cached_view_users') or not hasattr(self, 'cached_view_bundles'):
            return torch.tensor(0.0, device=self.device)

        UB_u, UI_u, BI_u = self.cached_view_users
        UB_b, UI_b, BI_b = self.cached_view_bundles

        # User view alignment (MSE)
        align_loss_u = torch.mean((UB_u - UI_u) ** 2) + torch.mean((UB_u - BI_u) ** 2) + torch.mean((UI_u - BI_u) ** 2)

        # Bundle view alignment (MSE)
        align_loss_b = torch.mean((UB_b - UI_b) ** 2) + torch.mean((UB_b - BI_b) ** 2) + torch.mean((UI_b - BI_b) ** 2)

        return (align_loss_u + align_loss_b) / 6.0

    def compute_proto_assignment(self, bi_feature):
        # bi_feature: [num_bundles, emb_size]
        # prototypes: [num_protos, emb_size]
        sim = F.cosine_similarity(bi_feature.unsqueeze(1), self.prototypes.unsqueeze(0), dim=-1)
        a_b = F.softmax(sim / self.proto_temp, dim=-1)
        return a_b

    def enhance_bi(self, bi_feature):
        a_b = self.compute_proto_assignment(bi_feature)
        proto_agg = torch.matmul(a_b, self.prototypes)
        bi_feature_prime = (1 - self.proto_alpha) * bi_feature + self.proto_alpha * proto_agg
        return bi_feature_prime, a_b

    def cal_proto_loss(self, a_b1, a_b2):
        # a_b1, a_b2: [num_bundles, num_protos]
        kl = torch.sum(a_b1 * (torch.log(a_b1 + 1e-10) - torch.log(a_b2 + 1e-10)), dim=1).mean()
        return kl

    def cal_proto_cl_loss(self, a_b1, a_b2):
        # Prototype-level contrastive learning (InfoNCE on assignments)
        # a_b1, a_b2: [batch_size, num_protos]
        a_b1 = F.normalize(a_b1, p=2, dim=1)
        a_b2 = F.normalize(a_b2, p=2, dim=1)
        pos_score = torch.sum(a_b1 * a_b2, dim=1)  # [batch_size]
        ttl_score = torch.matmul(a_b1, a_b2.t())     # [batch_size, batch_size]
        pos_score = pos_score / self.proto_temp
        ttl_score = ttl_score / self.proto_temp
        # numerically stable InfoNCE
        cl = -torch.mean(pos_score - torch.logsumexp(ttl_score, dim=1))
        return cl

    def cal_loss(self, users_feature, bundles_feature, bundles=None):
        # users_feature / bundles_feature: [bs, 1+neg_num, emb_size]
        pred = torch.sum(users_feature * bundles_feature, 2)
        bpr_loss = cal_bpr_loss(pred)

        # cl is abbr. of "contrastive loss"
        u_view_cl = self.cal_c_loss(users_feature, users_feature)
        b_view_cl = self.cal_c_loss(bundles_feature, bundles_feature)

        c_losses = [u_view_cl, b_view_cl]

        c_loss = sum(c_losses) / len(c_losses)

        # prototype-prediction auxiliary loss: a bundle representation should
        # be able to predict its own prototype assignment
        proto_pred_loss = torch.tensor(0.0, device=users_feature.device)
        if bundles is not None and hasattr(self, 'cached_a_b'):
            batch_bundle_ids = bundles[:, 0]
            a_b = self.cached_a_b[batch_bundle_ids]  # [bs, num_protos]
            bundle_repr = bundles_feature[:, 0, :]  # [bs, emb_size]
            # linear prediction of the prototype assignment
            pred_logits = torch.matmul(bundle_repr, self.prototypes.t())  # [bs, num_protos]
            pred_a_b = F.log_softmax(pred_logits / self.proto_temp, dim=-1)
            # KL divergence between the prediction and the cached assignment
            proto_pred_loss = F.kl_div(pred_a_b, a_b, reduction='batchmean')

        return bpr_loss, c_loss, proto_pred_loss


    def forward(self, batch, ED_drop=False):
        # the edge drop can be performed by every batch or epoch, should be controlled in the train loop
        if ED_drop:
            self.UB_propagation_graph = self.get_propagation_graph(self.ub_graph, self.conf["UB_ratio"])

            self.UI_propagation_graph = self.get_propagation_graph(self.ui_graph, self.conf["UI_ratio"])
            self.UI_aggregation_graph = self.get_aggregation_graph(self.ui_graph, self.conf["UI_ratio"])

            self.BI_propagation_graph = self.get_propagation_graph(self.bi_graph, self.conf["BI_ratio"])
            self.BI_aggregation_graph = self.get_aggregation_graph(self.bi_graph, self.conf["BI_ratio"])

        # users: [bs, 1]
        # bundles: [bs, 1+neg_num]
        users, bundles = batch
        users_rep, bundles_rep = self.get_multi_modal_representations()

        users_embedding = users_rep[users].expand(-1, bundles.shape[1], -1)
        bundles_embedding = bundles_rep[bundles]

        bpr_loss, c_loss, proto_pred_loss = self.cal_loss(users_embedding, bundles_embedding, bundles=bundles)

        # Prototype consistency loss (KL)
        proto_loss = getattr(self, 'cached_proto_loss', torch.tensor(0.0, device=self.device))
        if not isinstance(proto_loss, torch.Tensor):
            proto_loss = torch.tensor(0.0, device=self.device)

        # Prototype-level contrastive loss (batch-level InfoNCE on assignments)
        proto_cl_loss = torch.tensor(0.0, device=self.device)
        if self.beta > 0 and hasattr(self, 'cached_a_b1') and hasattr(self, 'cached_a_b2'):
            batch_bundle_ids = bundles.view(-1).unique()
            a_b1_batch = self.cached_a_b1[batch_bundle_ids]
            a_b2_batch = self.cached_a_b2[batch_bundle_ids]
            proto_cl_loss = self.cal_proto_cl_loss(a_b1_batch, a_b2_batch)

        # Prototype orthogonality regularization
        proto_ortho = torch.norm(
            torch.matmul(self.prototypes, self.prototypes.t())
            - torch.eye(self.num_protos, device=self.device),
            p='fro'
        )

        # Cross-view alignment loss
        cross_view_loss = self.cal_cross_view_alignment_loss()

        return bpr_loss, c_loss, proto_loss + 0.2 * proto_cl_loss, proto_ortho, proto_pred_loss, cross_view_loss


    def evaluate(self, propagate_result, users):
        users_feature, bundles_feature = propagate_result
        scores = torch.mm(users_feature[users], bundles_feature.t())
        return scores

    def extract_bundle_prototype_features(self):
        """
        Export the prototype-related bundle features used for the UMAP analysis.

        Returns
        -------
        bi_feature       : original B-I bundle representation  [num_bundles, emb_size]
        enhanced_feature : prototype-enhanced B-I representation [num_bundles, emb_size]
        a_b              : soft assignment of every bundle [num_bundles, num_protos]
        """
        self.eval()
        with torch.no_grad():
            # original B-I bundle representation (before prototype enhancement)
            BI_bundles_feature, _ = self.propagate(
                self.BI_propagation_graph_ori,
                self.bundles_feature,
                self.items_feature,
                "BI",
                self.BI_layer_coefs,
                test=True
            )
            # enhanced representation and its soft assignment
            enhanced_feature, a_b = self.enhance_bi(BI_bundles_feature)
        return BI_bundles_feature, enhanced_feature, a_b
